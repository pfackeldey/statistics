
outputs of all three programs are in the .pdf
also the explanations and other answers are there


--------TASK 1--------------
python program
run by "python task1.py"
If this doesnt work, try python 2.7
eg with "python27 task1.py"


--------TASK 2--------------
c++ program
generates plots and bash output

run by "g++ rooFit.cc `root-config --cflags --libs` -lRooFit -lRooFitCore"

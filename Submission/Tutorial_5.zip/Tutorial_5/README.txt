--------TASK 2--------------
python program
run by "python task2.py"
If this doesnt work, try python 2.7
eg with "python27 task2.py"

solution for task b) is in the python file and in the pdf

--------TASK 1+3--------------
All other solutions in the pdf

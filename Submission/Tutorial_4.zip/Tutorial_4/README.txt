--------TASK 1--------------
a:
python program, run by "python rand.py", saves al pngs
b:
.cc file didnt work, wrote my own python program, which does the same
run by "python elephant.py"

------TASK 2-----------------
python program, run by "python pi.py"
or with argument -n : eg. "python pi.py --n 10000"



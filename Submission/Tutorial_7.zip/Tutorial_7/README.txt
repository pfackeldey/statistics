
Find explanations for the code in task 1 in the .odt file.
Please read before inspecting/running the .py.




--------TASK 1--------------
python program
run by "python task1.py"
If this doesnt work, try python 2.7
eg with "python27 task1.py"

--------TASK 2--------------
python program
run by "python task2.py"
If this doesnt work, try python 2.7
eg with "python27 task2.py"

solution for task b) is in the odt file.


